// Simple client-side site search for Belle & Carrie Rehabilitation Yoga
// Builds an index of the site's real pages/content and matches against the query.

(function () {
	var siteIndex = [
		{
			title: "Home",
			url: "index.html",
			excerpt: "Belle & Carrie Rehabilitation Yoga is a dedicated studio helping people recover from injury, ease chronic pain and rebuild strength through slow, mindful movement.",
			keywords: "home welcome injury safe programming small class sizes flexible scheduling testimonials"
		},
		{
			title: "About Us",
			url: "about.html",
			excerpt: "Learn about our approach to rehabilitation yoga, our instructors' backgrounds and the philosophy behind every class we teach.",
			keywords: "about story philosophy mission instructors qualifications history"
		},
		{
			title: "Classes: Beginners",
			url: "classes.html",
			excerpt: "Foundational breathing and gentle stretches for those new to rehabilitation yoga. MWF 8AM-9AM, TTHS 10AM-11AM.",
			keywords: "beginners class schedule breathing gentle stretches mwf tths"
		},
		{
			title: "Classes: Intermediate",
			url: "classes.html",
			excerpt: "Building strength and balance once foundational mobility has been restored. MWF 10AM-11AM, TTHS 1PM-2PM.",
			keywords: "intermediate class schedule strength balance mobility"
		},
		{
			title: "Classes: Advanced",
			url: "classes.html",
			excerpt: "Deeper stretches and longer holds for students ready to progress further. MWF 1PM-2PM, TTHS 8AM-9AM.",
			keywords: "advanced class schedule deep stretches longer holds"
		},
		{
			title: "Instructors",
			url: "instructors.html",
			excerpt: "Meet Belle Humpfree, Jacob Collern, Edward Blanche and Carrie Waldorf, our certified rehabilitation yoga instructors.",
			keywords: "instructors teachers belle jacob edward carrie certified staff"
		},
		{
			title: "Contact Us",
			url: "contact.html",
			excerpt: "Send us an inquiry about classes, private sessions or general questions and our team will respond promptly.",
			keywords: "contact inquiries form phone email location booking"
		},
		{
			title: "Blog: Summer Yoga Classes",
			url: "blog.html",
			excerpt: "Details on our seasonal summer schedule and outdoor rehabilitation yoga sessions.",
			keywords: "blog summer classes schedule outdoor seasonal"
		},
		{
			title: "Blog: Inner Peace",
			url: "blog.html",
			excerpt: "How a consistent rehabilitation yoga practice can support mental calm alongside physical recovery.",
			keywords: "blog inner peace mindfulness calm mental health"
		},
		{
			title: "Blog: A Strong and Flexible Body",
			url: "singlepost.html",
			excerpt: "Why building strength and flexibility together leads to safer, longer-lasting recovery outcomes.",
			keywords: "blog strong flexible body recovery strength flexibility"
		}
	];

	function getQueryParam(name) {
		var params = new URLSearchParams(window.location.search);
		return params.get(name) || "";
	}

	function runSearch(query) {
		var q = query.trim().toLowerCase();
		if (!q) return [];
		var terms = q.split(/\s+/);
		return siteIndex.filter(function (item) {
			var haystack = (item.title + " " + item.excerpt + " " + item.keywords).toLowerCase();
			return terms.some(function (term) {
				return haystack.indexOf(term) !== -1;
			});
		});
	}

	function renderResults(query) {
		var resultsEl = document.getElementById("search-results");
		var summaryEl = document.getElementById("search-summary");
		if (!resultsEl || !summaryEl) return;

		var results = runSearch(query);
		resultsEl.innerHTML = "";

		if (!query.trim()) {
			summaryEl.textContent = "Type a keyword above to search classes, instructors and blog articles.";
			return;
		}

		summaryEl.textContent = results.length
			? 'Showing ' + results.length + ' result' + (results.length === 1 ? '' : 's') + ' for "' + query + '"'
			: 'No results found for "' + query + '". Try a different keyword, such as "beginners", "instructors" or "contact".';

		results.forEach(function (item) {
			var li = document.createElement("li");
			var h3 = document.createElement("h3");
			var a = document.createElement("a");
			a.href = item.url;
			a.textContent = item.title;
			h3.appendChild(a);
			var p = document.createElement("p");
			p.textContent = item.excerpt;
			li.appendChild(h3);
			li.appendChild(p);
			resultsEl.appendChild(li);
		});
	}

	document.addEventListener("DOMContentLoaded", function () {
		var query = getQueryParam("q");
		var searchInput = document.getElementById("search-input");
		if (searchInput && query) {
			searchInput.value = query;
		}
		renderResults(query);
	});
})();
