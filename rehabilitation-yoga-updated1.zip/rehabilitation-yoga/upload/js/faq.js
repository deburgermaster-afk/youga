// Simple accordion behaviour for FAQ sections
(function () {
	document.addEventListener("DOMContentLoaded", function () {
		var questions = document.querySelectorAll(".faq-question");
		questions.forEach(function (btn) {
			btn.addEventListener("click", function () {
				var item = btn.parentElement;
				var wasOpen = item.classList.contains("open");
				document.querySelectorAll(".faq > li").forEach(function (li) {
					li.classList.remove("open");
				});
				if (!wasOpen) {
					item.classList.add("open");
				}
			});
		});
	});
})();
